# Emotion Detection using KNN Classifier

This project is about emotion detection using machine learning models in a set of images. The dataset used in this project is a set of images of faces with different emotions. The emotions are labeled as follows:
- 0 for Angry
- 1 for Disgust
- 2 for Fear
- 3 for Happy
- 4 for Sad
- 5 for Surprise
- 6 for Neutral

The images are represented as a list of pixels in a CSV file. The first column in the CSV file is the label of the image and the remaining columns are the pixels of the image.

## Project Structure

The project has the following structure:

- `src/main.py`: This is the main file that runs the project. It imports the KNN classifier, data loader, and image visualizer. It uses the data loader to load the training and test data, trains the KNN classifier with the training data, and tests the classifier with the test data. It also uses the image visualizer to display some of the images.

- `src/knn_classifier.py`: This file implements the KNN classifier. It exports a class `KNNClassifier` which has methods for training the classifier (`train`) and predicting the class of an image (`predict`).

- `src/utils/data_loader.py`: This file exports a function `load_data` which loads the data from a CSV file.

- `src/visualizer/image_visualizer.py`: This file exports a function `display_image` which displays an image.

- `data/trainYX.csv` and `data/testYX.csv`: These files contain the training and test data.

- `results/accuracy_results.txt`: This file contains the accuracy of the KNN classifier for different values of K.

## How to Run the Project

To run the project, navigate to the `src` directory and run the `main.py` file. This will train the KNN classifier with the training data and test it with the test data. The accuracy of the classifier for different values of K will be written to the `results/accuracy_results.txt` file.

## Dependencies

This project requires the following Python libraries:

- numpy
- matplotlib
- PIL
- csv

Make sure to install these libraries before running the project.