import csv
import numpy as np

def load_data(file_path):
    """
    Load data from a CSV file.

    Args:
    file_path (str): The path to the CSV file.

    Returns:
    tuple: A tuple containing the labels and the data as numpy arrays.
    """
    labels = []
    data = []

    with open(file_path, 'r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            labels.append(int(row[0]))
            data.append([int(pixel) for pixel in row[1:]])

    return np.array(labels), np.array(data)