import numpy as np
from collections import Counter

class KNNClassifier:
    def __init__(self):
        self.training_data = None
        self.training_labels = None

    def train(self, data, labels):
        self.training_data = data
        self.training_labels = labels

    def predict(self, test_data, k):
        predictions = []
        for test in test_data:
            distances = np.sqrt(np.sum(np.square(self.training_data - test), axis=1))
            k_indices = np.argpartition(distances, k)[:k]
            k_nearest_labels = self.training_labels[k_indices]
            most_common = Counter(k_nearest_labels).most_common(1)
            predictions.append(most_common[0][0])
        return predictions