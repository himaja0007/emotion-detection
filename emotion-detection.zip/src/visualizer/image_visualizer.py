import matplotlib.pyplot as plt
from PIL import Image
import numpy as np

def display_image(pixels):
    # Reshape the pixels into a 48x48 array
    pixels = np.array(pixels, dtype=np.uint8).reshape((48, 48))

    # Create an image from the array of pixels
    new_image = Image.fromarray(pixels)

    # Display the image
    plt.imshow(new_image)
    plt.show()