import csv
import numpy as np
from knn_classifier import KNNClassifier
from utils.data_loader import load_data
from visualizer.image_visualizer import display_image

def main():
    # Load training and test data
    train_labels, train_data,  = load_data('../data/trainYX.csv')
    test_labels, test_data,  = load_data('../data/testYX.csv')
    
    # # use some amount of data for training because computaion resource are low
    # train_data = train_data[:100]
    # train_labels = train_labels[:100]
    
    # # use some amount of data for testing because computaion resource are low
    # test_data = test_data[:10]
    # test_labels = test_labels[:10]
    
    print(f'Training data shape: {train_data.shape}')
    print(f'Training labels shape: {train_labels.shape}')
    print(f'Test data shape: {test_data.shape}')
    print(f'Test labels shape: {test_labels.shape}')
    # Initialize KNN classifier
    knn = KNNClassifier()

    # Train KNN classifier
    knn.train(train_data, train_labels)

    # Test KNN classifier with different values of K
    accuracies = []
    for k in range(1, 11):
        predictions = knn.predict(test_data, k)
        accuracy = np.mean(predictions == test_labels)
        accuracies.append(accuracy)
        print(f'Accuracy for k={k}: {accuracy}')

    # Write accuracies to file
    with open('../results/accuracy_results.txt', 'w') as f:
        for k, accuracy in enumerate(accuracies, 1):
            f.write(f'Accuracy for k={k}: {accuracy}\n')

    # Display some of the images
    for i in range(5):
        display_image(test_data[i])

if __name__ == '__main__':
    main()